#!/bin/sh

# Function to check if a package is installed
check_package() {
    if [ -f /usr/local/tce.installed/$1 ]; then
        return 0  # Package is installed
    else
        return 1  # Package is not installed
    fi
}

# Check and install ffmpeg4.tcz if needed
if ! check_package "ffmpeg4.tcz"; then
    echo "ffmpeg4.tcz is not installed. Installing now..."
    tce-load -wi ffmpeg4.tcz
    if [ $? -ne 0 ]; then
        echo "Failed to install ffmpeg4.tcz. Please check your internet connection and try again."
        exit 1
    fi
    echo "ffmpeg4.tcz installed successfully."
else
    echo "ffmpeg4.tcz is already installed."
fi

# Create a startup script for playing the video
cat > /opt/bootlocal.sh << 'EOF'
#!/bin/sh

# Wait a few seconds for X to start properly
sleep 10

# Set display variable
export DISPLAY=:0

# Start video playback in a loop
# -fs for fullscreen
# -noborder removes window decoration
# -x 1920 -y 1080 sets window size (adjust to your resolution)
# -alwaysontop keeps video on top
# -nokeepaspect stretches to full screen
# -window_title "" removes title
while true; do
    ffplay -fs -noborder -x 1920 -y 1080 -alwaysontop -nokeepaspect -window_title "" \
    -loop 0 -autoexit -loglevel quiet \
    -showmode 0 -nostats \
    /home/VideoPlayer/video.mp4
done &
EOF

# Make bootlocal.sh executable
chmod +x /opt/bootlocal.sh

# Backup changes
filetool.sh -b

echo "Installation complete. Please reboot for changes to take effect."