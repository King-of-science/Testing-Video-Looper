# Right now this script will upload the video file and bash script to github. there is also a function for deleting the file once I get around to implimenting it
#I thin kit would be better to instead, create a new submodule and upload the files to their. That way it's like an actual feed, with an ID and everything


import requests
import base64
import json
import os

def upload_to_github(file_path, github_path, repo, token):
    # GitHub API endpoint
    url = f"https://api.github.com/repos/{repo}/contents/{github_path}"
    
    # Read file content
    with open(file_path, 'rb') as file:
        content = file.read()
    
    # Encode content to base64
    content_encoded = base64.b64encode(content).decode('utf-8')
    
    # API request headers
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    # API request data
    data = {
        "message": f"Upload {github_path}",
        "content": content_encoded
    }
    
    # Make the API request
    response = requests.put(url, headers=headers, data=json.dumps(data))
    
    if response.status_code == 201:
        print(f"Successfully uploaded {file_path} to {github_path}")
    else:
        print(f"Failed to upload {file_path}. Status code: {response.status_code}")
        print(response.json())


def delete_from_github(github_path, repo, token):
    # GitHub API endpoint
    url = f"https://api.github.com/repos/{repo}/contents/{github_path}"
    
    # API request headers
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    # First, get the file's SHA
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        print(f"Failed to get file information. Status code: {response.status_code}")
        print(response.json())
        return False
    
    file_sha = response.json()["sha"]
    
    # API request data
    data = {
        "message": f"Delete {github_path}",
        "sha": file_sha
    }
    
    # Make the delete request
    response = requests.delete(url, headers=headers, data=json.dumps(data))
    
    if response.status_code == 200:
        print(f"Successfully deleted {github_path}")
        return True
    else:
        print(f"Failed to delete {github_path}. Status code: {response.status_code}")
        print(response.json())
        return False


def create_submodule():
    
    
    pass



def main():
    # Your GitHub repository details
    repository = "smithbeu/ThinClient-VideoFeed"
    token = "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"  # Replace with your token
    
    # Files to upload
    video = os.path.abspath("video.mp4")
    script = os.path.abspath("install.sh")
    
    files = [
        {
            "local_path": video,  # Local file that will be uploaded
            "github_path": "video.mp4"  # Remote file that will be in the repository
        },
        {
            "local_path": script,  # Local file that will be uploaded
            "github_path": "install.sh"  # Remote file that will be in the repository
        }
    ]
    
    # Upload each file
    for file in files:
        upload_to_github(file["local_path"], file["github_path"], repository, token)

if __name__ == "__main__":
    main()
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	